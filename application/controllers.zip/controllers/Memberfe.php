<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Memberfe extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Mmember');
        $this->load->model('Mfrontend');
    }

    public function act_login()
    {
        $u = $this->input->post('username');
        $p = $this->input->post('password');

        $cek = $this->Mmember->cek_login($u, $p)->num_rows();
        $result = $this->Mmember->cek_login($u, $p)->result();
        if ($cek == 1) {
            $data_session = array(
                'userName' => $u,
                'id' => $result[0]->idKonsumen,
                'status' => 'login'
            );
            $this->session->set_userdata($data_session);
            //redirect('memberfe');
            if ($cek == 1) {
                echo "<script>alert('Login berhasil!' );
                              window.location='" . site_url('memberfe') . "';
                              </script>";
            } else {
                echo "<script>alert('Login berhasil!' );
                              window.location='" . site_url('memberfe') . "';
                              </script>";
            }
        } else {
            echo "<script>alert('Login gagal!' );
                              window.location='" . site_url('home/login') . "';
                              </script>";
        }
    }

    public function index()
    {
        if (empty($this->session->userdata('userName'))) {
            redirect('Memberfe/act_login');
        }

        $this->template->load('layout_member', 'member/dashboard/member');
    }

    public function home()
    {
        //$data['member'] = $this->Mcrud->get_all_data('tbl_member')->result_array();
        $data['kategori'] = $this->Mfrontend->get_all_data_kategori()->result();
        $data['produk_terbaru'] = $this->Mfrontend->get_all_data_produk_terbaru()->result();
        $this->template->load('layout_member', 'member/home/index', $data);
    }

    public function logout()
    {
        $this->session->sess_destroy();
        redirect('home/login');
    }
}
